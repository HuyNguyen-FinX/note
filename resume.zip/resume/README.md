# Resume Variants: Nguyen Gia Huy

Bộ CV được tối ưu riêng cho từng vị trí. Tất cả viết bằng LaTeX, dùng chung một template, xuất ra PDF A4 1 trang, ATS-friendly.

## Cấu trúc

```text
resume/
├── original/
│   ├── original_cv.tex        # bản sao main.tex gốc (giữ nguyên, kể cả lỗi)
│   └── original_cv.pdf        # bản gốc đã compile, dùng để đối chiếu
├── analysis/
│   ├── profile-analysis.md    # phân tích kinh nghiệm, bằng chứng, lỗi của CV gốc
│   └── role-matching.md       # mức độ phù hợp với từng vị trí, kỹ năng còn thiếu
├── templates/
│   └── resume-template.tex    # layout, font, thông tin cá nhân, timeline, học vấn
├── latex/                     # 1 file .tex cho mỗi vị trí
├── pdf/                       # PDF đã build
├── scripts/
│   └── build-all.sh           # build và kiểm tra toàn bộ
└── README.md
```

| File | Vị trí |
|---|---|
| `backend-engineer` | Backend Engineer (general) |
| `software-engineer` | Software Engineer (general) |
| `python-backend` | Python Backend Developer |
| `golang-backend` | Golang Backend Developer |
| `java-backend` | Java Backend Developer (Java/Spring Boot) |
| `data-engineer` | Data Engineer |
| `devops-engineer` | DevOps Engineer |
| `cloud-engineer` | Cloud Engineer |
| `platform-engineer` | Platform Engineer |
| `fintech-backend` | Core Banking / FinTech Backend Engineer *(bản bổ sung)* |

## Build

```bash
cd resume
./scripts/build-all.sh                    # build tất cả
./scripts/build-all.sh data-engineer      # build 1 hoặc vài bản
ENGINE=docker ./scripts/build-all.sh      # ép dùng engine cụ thể
```

Script tự chọn engine theo thứ tự `latexmk` → `xelatex` → `tectonic` → `docker` (image `texlive/texlive`).
Template dùng `fontspec`, nên **cần XeLaTeX hoặc LuaLaTeX**; `pdflatex` không chạy được.

Cài nhanh trên macOS (không cần sudo):

```bash
brew install tectonic poppler   # tectonic = engine LaTeX, poppler = pdftotext/pdfinfo cho bước kiểm tra
```

Sau khi build, script tự kiểm tra từng PDF:
- số trang (cảnh báo nếu nhiều hơn 1 trang)
- text trích xuất được bằng `pdftotext` (mô phỏng cách ATS đọc)
- không còn ký tự ligature (`ﬁ`, `ﬂ`...) hoặc ký tự lỗi
- có đủ họ tên, email và cả 4 công ty
- không có overfull box (chữ tràn lề)

File trung gian và log nằm trong `.build/`, có thể xoá thoải mái.

## Chỉnh sửa

### Thông tin dùng chung: sửa 1 lần trong `templates/resume-template.tex`
- **Thông tin cá nhân**: các biến `\cvname`, `\cvemail`, `\cvphone`, `\cvlinkedin`.
- **Công ty, chức danh, thời gian**: các macro `\jobGalaxyFinX`, `\jobVietlink`, `\jobVNPAY`, `\jobEsolLabs`.
- **Dự án**: `\projDattingQ`, `\projMeetQ`.
- **Học vấn và chứng chỉ**: `\cveducation`.
- **Font, lề, cỡ chữ**: phần FONT, PAGE SETUP và `\cvfontsize`.

Vì timeline nằm ở một chỗ duy nhất, các bản CV không thể lệch nhau về chức danh hay ngày tháng.

### Nội dung riêng của từng vị trí: sửa trong `latex/<role>.tex`
Mỗi file gồm:
```latex
\input{../templates/resume-template.tex}
\begin{document}
\cvheader{Backend Engineer}              % tiêu đề vị trí ứng tuyển
\cvsummary{...}                          % professional summary
\begin{cvskills}
Languages: & Golang, Python \\           % mỗi dòng: nhãn & danh sách
\end{cvskills}
\cvsection{Work Experience}
\jobGalaxyFinX                           % header công ty (từ template)
\begin{itemize} \item ... \end{itemize}  % bullet riêng cho vị trí này
...
\cveducation
\end{document}
```

### Thêm một vị trí mới
1. Copy file gần nhất trong `latex/`, ví dụ `cp latex/backend-engineer.tex latex/sre.tex`.
2. Sửa `\cvheader`, summary, skills, rồi sắp xếp lại và viết lại bullet.
3. Chạy `./scripts/build-all.sh sre`.

### Nếu CV bị tràn sang trang 2
Theo thứ tự ưu tiên:
1. Bỏ bullet ít liên quan nhất với vị trí.
2. Rút gọn những bullet có dòng cuối chỉ 1–2 chữ.
3. Gộp 2 bullet của dự án thành 1.
4. Biện pháp cuối: giảm `\cvfontsize` (ví dụ `9.2pt/10.8pt`) bằng cách đặt
   `\renewcommand{\cvfontsize}{\fontsize{9.2pt}{10.8pt}\selectfont}` trước `\cvheader`.

## Quy tắc nội dung (giữ khi sửa)
- Không thêm công nghệ, số liệu hay thành tích không có trong kinh nghiệm thật.
- Java/Spring Boot, FastAPI, RabbitMQ, Jenkins, ArgoCD, Consul, HashiCorp Vault hiện **chỉ là skill được liệt kê**. Không viết thành bullet kinh nghiệm cho tới khi có dự án thật.
- Cấu trúc bullet: **Hành động + Công nghệ + Vấn đề kỹ thuật + Kết quả**.
- "nearly three years" đúng tại thời điểm 10/2026. Hãy cập nhật khi thời gian trôi qua (xem `analysis/profile-analysis.md`).
- Tránh ký tự CJK và icon. Giữ text thuần để ATS đọc được.
